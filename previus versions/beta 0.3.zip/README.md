# typr.github.io

## what is this?
Typr is a little project i made for fun
using typr you can test yourself and seeing how fast you can type.
you can also use it to train your typing 



## TO DO:
[ ] more quotes 

[] select if you want long or short quotes
[] seperate file for quotes